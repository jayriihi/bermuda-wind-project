from flask import Flask

app = Flask(__name__)
app.secret_key = "riihiluoma"

from app import views